Datasets :

- llm-detect-ai-generated-text-data : from the competition
- DAIGT_Proper_Train_Dataset : train_drcat_01.csv, train_drcat_02.csv, train_drcat_03.csv, train_drcat_04.csv

- Why we need to add DAIGT_Proper_Train_Dataset as a dataset for this project?

The answer : remedy the lack of data which is a major problem in ML.


- Statement from this kagglers :

"
About this Dataset
Version 2 updated on 11/2/2023:

Since there is no proper train dataset for LLM - Detect AI Generated Text competition, I decided to create one.
"

Please follow this link to understand more :  https://www.kaggle.com/code/alexia/kerasnlp-starter-notebook-llm-detect-ai-generate/input